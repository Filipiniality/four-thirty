#include <pthread.h>          /* pthread_create, pthread_join */
#include <semaphore.h>        /* sem_init, sem_wait, sem_post */
#include <stdlib.h>           /* malloc, free */
#include <stdio.h>            /* printf */
#define BUFSIZE 10
#define MAX 50

typedef struct {
  int *buf;                   /* Buffer array */
  int n;                      /* Maximum number of slots */
  int front;                  /* buf[(front+1)%n] is first item */
  int rear;                   /* buf[rear%n] is last item */
  sem_t mutex;                /* Protects accesses to buf */
  sem_t slots;                /* Counts available slots */
  sem_t items;                /* Counts available items */
} sbuf_t;

/* Create an empty, bounded, shared FIFO buffer with n slots */
void sbuf_init(sbuf_t *sp, int n) {
  sp->buf = calloc(n, sizeof(int));
  sp->n = n;                  /* Buffer holds max of n items */
  sp->front = sp->rear = 0;   /* Empty buffer iff front == rear */
  sem_init(&sp->mutex, 0, 1); /* Binary semaphore for locking */
  sem_init(&sp->slots, 0, n); /* Initially, buf has n empty slots */
  sem_init(&sp->items, 0, 0); /* Initially, buf has zero data items */
}

/* Clean up buffer sp */
void sbuf_deinit(sbuf_t *sp) {
 free(sp->buf);
}

/* Insert item onto the rear of shared buffer sp */
void sbuf_insert(sbuf_t *sp, int item)
{
 sem_wait(&sp->slots);                 /* Wait for available slot */
 sem_wait(&sp->mutex);                 /* Lock the buffer */
 sp->buf[(++sp->rear)%(sp->n)] = item; /* Insert the item */
 sem_post(&sp->mutex);                 /* Unlock the buffer */
 sem_post(&sp->items);                 /* Announce available item */
 }

/* Remove and return the first item from buffer sp */
int sbuf_remove(sbuf_t *sp)
{
 int item;
 sem_wait(&sp->items);                  /* Wait for available item */
 sem_wait(&sp->mutex);                  /* Lock the buffer */
 item = sp->buf[(++sp->front)%(sp->n)]; /* Remove the item */
 sem_post(&sp->mutex);                  /* Unlock the buffer */
 sem_post(&sp->slots);                  /* Announce available slot */
 return item;
 }

sbuf_t sbuf;

/* Thread routines */
void *producer( void *arg ) {
  int i;
  for ( i = 0; i < MAX; i++ )
    sbuf_insert( &sbuf, i );
  return NULL;
}

void *consumer( void *arg ) {
  int i;
  for ( i = 0; i < MAX; i++ )
    printf( "%d\n", sbuf_remove( &sbuf ) );
  return NULL;
}

/* main() thread */
int main( int argc, char **argv ) {
  pthread_t tid1, tid2;

  /* Create a bounded buffer with BUSIZE */
  sbuf_init( &sbuf, BUFSIZE );

  /* Create threads and wait for them to finish */
  pthread_create( &tid1, NULL, producer, NULL );
  pthread_create( &tid2, NULL, consumer, NULL );
  pthread_join( tid1, NULL );
  pthread_join( tid2, NULL );
}

